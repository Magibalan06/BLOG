import "./App.css";
import React from "react";
import 'antd/dist/antd.css';
import './components/CssFile.css';
import './components/Combine.css';
import './components/Combine02.css';
import './components/CssFile02.css';
import Combine from "./components/Combine";
import Combine02 from "./components/Combine02";
import { Routes, Route } from 'react-router-dom';
// import { NavBar } from './components/NavBar'; 


function App() {
  return( 
  <div className="App">
    {/* <NavBar/> */}
    <Routes>
      <Route path='/' element = { <Combine/> } />
      <Route path='signup' element = { <Combine02/> } />
    </Routes>

</div>
)
  
}

export default App;
