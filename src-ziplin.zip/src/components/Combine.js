import React from "react";
import Left from "./Left";
import Right from "./Right";
function Combine () {
    return (
        <div className="component">
            <div className="Left-Component">
                <Left/>
            </div>
            <div className="Right-Component">
                <Right/>
            </div>
        </div>
    )
} 
export default Combine