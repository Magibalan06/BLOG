import React from "react";
import Left02 from "./Left02";
import Right02 from "./Right02";
function Combine02 () {
    return (
        <div className="component02">
            <div className="Left-Component02">
                <Left02/>
            </div>
            <div className="Right-Component02">
                <Right02/>
            </div>
        </div>
    )
} 
export default Combine02