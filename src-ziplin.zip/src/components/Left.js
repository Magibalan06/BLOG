import React from 'react';
import { Button, Form, Input } from 'antd';
import { useNavigate } from 'react-router-dom';

function Left() {
    const navigate = useNavigate()
  return (
    <div>
        <div className="Body">
            <img className="Blog" src ="Blog.png" alt="BLOG"/>
        </div>
        <Form layout='vertical'>
            <Form.Item name="email" label="E-mail" className='E-Mail' 
            rules={[
                {
                  type: 'email',
                  message: 'The input is not valid E-mail!',
                },
                {
                  required: true,
                  message: 'Please input your E-mail!',
                },
              ]}>

                <Input className='Input-E-Mail' placeholder='Email'/>

            </Form.Item>
            <Form.Item name="password" label="Password" className='Password'
        rules={[
          {
            required: true,
            message: 'Please input your password!',
          },
        ]}
        hasFeedback
      >
        <Input.Password className='Input-Password' placeholder='Password'/>
      </Form.Item>
      <Button type="primary" htmlType="submit" className='Signin'>
          Signin
        </Button>
        </Form>
        {/* <h4 className="Email">Email</h4>
        <Input className="input-Email" placeholder="Email"/>
        <div className="password-content">
            <h4 className="Password">Password</h4>
            <h4 className="Forget-Password">Forget Password?</h4>
        </div>
        <Input className="input-Password" placeholder="Password"/>
        <Button className="Signin">Signin</Button> */}
        <p className="account">
            Don't have an account? 
            <span className='Signup'>
                <nav>
                    {/* <NavLink className='Signup' to = '/' ><Button type='link' onClick={() => navigate ( '-1' )}>Signup</Button></NavLink> */}
                    <Button className='Signup' type='link' onClick={() => navigate('signup')}>Signup</Button>
                </nav>
            </span>
        </p>
    </div>
  )
}

export default Left