import { Button, Input } from 'antd';
import React from 'react';
import { useNavigate } from 'react-router-dom'; 


function Left02() {
    const navigate = useNavigate()
  return (
    <div>
        <div className="Body">
            <img className="Blog" src ="Blog.png" alt="BLOG"/>
        </div>
        {/* <div className='name-Head'>
            <h4 className='fName'>First Name</h4>
            <h4 className='lName'>Last Name</h4>
            </div>
            <div className='name-Content'>
            <Input className='input-fName' placeholder='Email'/>
            <Input className='input-lName' placeholder='Email'/>
        </div>
        <h4 className="Email02">Email</h4>
        <Input className="input-Email02" placeholder="Enter Email"/>
        <h4 className='Password02'>Password</h4>
        <Input className='input-Password02' placeholder='Password'/>
        <h4 className='cPassword02'>Confirm Password</h4>
        <Input className='input-cPassword02' placeholder='Confirm Password'/>
        <Button className='Signup02'>Signup</Button> */}
        <p className="account">
            Don't have an account? 
            <span className='Signup'>
                <nav>
                    <Button className='Signin02' type='link' onClick={() => navigate('/')}>Signin</Button>
                </nav>
            </span>
        </p>
    </div>
  )
}

export default Left02