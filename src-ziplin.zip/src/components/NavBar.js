import { NavLink } from 'react-router-dom';
import React from 'react';

export const NavBar = () => {
    return (
        <nav>
            <NavLink className='Signup' to = '/'>Home</NavLink>
        </nav>
    )
}