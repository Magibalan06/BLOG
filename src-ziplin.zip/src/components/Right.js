import React from 'react';
import RightBottom from './RightBottom';

function Right() {
  return (
    <div>
        <div className='Discover'>
            Discover the unknown
        </div>
        {/* <img className="Blog" src ="Blog.png" alt="BLOG"/> */}
        <img className='group-pic' src='pic01.png' alt='group'/>
        <RightBottom/>
    </div>
  )
}

export default Right