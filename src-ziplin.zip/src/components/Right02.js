import React from 'react';
import RightBottom02 from './RightBottom02';

function Right02() {
  return (
    <div>
        <div className='Discover02'>
            Discover the unknown
        </div>
        {/* <img className="Blog" src ="Blog.png" alt="BLOG"/> */}
        <img className='group-pic02' src='pic01.png' alt='group'/>
        <RightBottom02/>
    </div>
  )
}

export default Right02