import React from 'react'

function RightBottom() {
  return (
    <div className='RightBottom'></div>
  )
}

export default RightBottom