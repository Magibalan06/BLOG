import React from 'react'

function RightBottom02() {
  return (
    <div className='RightBottom02'></div>
  )
}

export default RightBottom02